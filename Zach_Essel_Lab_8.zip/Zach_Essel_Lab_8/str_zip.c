#include "string.h"
#include <stdlib.h>
#include <ctype.h>

/*
Returns  a  new  string consisting of  all of  the characters  of s1 and s2
interleaved  with  each other.  For  example,  if s1 is "Spongebob" and 
s2 is "Patrick", the function  returns  the string  "SPpaotnrgiecbkob"

First interlace the strings in the while loops until at least one string reachs the null char
Then countinue in a for loop to dump the rest of the longer string onto the end of the new string
Finally add null char, also a default for same length strings

User responsible for freeing memory of returned string
*/
char *str_zip(char *s1, char *s2)
{
	int length1 = my_strlen(s1);
	int length2 = my_strlen(s2);
	int count = 0;
	char *return_string = (char *) malloc ((length1+length2+1) * sizeof(char));
	
	while ((*(s1+(count/2)) != '\0') && (*(s2+(count/2)) != '\0'))
	{
		*(return_string+count) = *(s1+(count/2));
		*(return_string+count+1) = *(s2+(count/2));
		count += 2;
	}
	
	if (length1 > length2)
	{
		for (int i = 0; *(s1+(count/2)+i) != '\0'; ++i)
			*(return_string+count+i) = *(s1+(count/2)+i);
	}
	
	else if (length1 < length2)
	{
		for (int i = 0; *(s2+(count/2)+i) != '\0'; ++i)
			*(return_string+count+i) = *(s2+(count/2)+i);
	}
	
	*(return_string+length1+length2) = '\0';

	return return_string;
}
