#include "string.h"

/*
returns the index of the first occurrence of n in the string h or -1 if it isn't found.
*/
int find(char *h, char *n)
{
	int return_location = -1;
	int current_location;
	int complete_n = 0;
	int length_h = my_strlen(h);
	int length_n = my_strlen(n);
	
	for (current_location = 0; *(h+current_location) != '\0'; ++current_location)
	{
		if ((*(h+current_location) == *(n)) && (complete_n == 0))
		{
			if (length_n+current_location <= length_h)
			{
				complete_n = 1;
				for (int i = 0; i < length_n; ++i)
				{
					if (*(h+current_location+i) != *(n+i))
						complete_n = 0;
				}
				if (complete_n == 1)
					return_location = current_location;
			}
		}
	}
	return return_location;
}
