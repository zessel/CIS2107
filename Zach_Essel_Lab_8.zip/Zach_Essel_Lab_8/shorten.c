#include "string.h"

/*
Shortens  the string  s to new_len. If  the  original  length  of s is less than or  equal  to new_len, s is unchanged
*/
void shorten(char *s, int new_len)
{
	if (new_len < my_strlen(s))
		*(s+new_len) = '\0';
/*	int length = my_strlen(s);
	if (length > new_len)
	{
		char *temp = s;
		char *new_str = (char *) malloc((new_len+1) * sizeof(char));
		for (int i = 0; i <= new_len; ++i)
		{
			*(new_str+i) = *temp;
			temp++;
		}
		*(new_str+new_len) = '\0';
		printf("*****%s***** %d\n", new_str, &*new_str);
		s = new_str;
		printf("-----%s----- %d\n", s, &*s);
	}*/
	
		
}
