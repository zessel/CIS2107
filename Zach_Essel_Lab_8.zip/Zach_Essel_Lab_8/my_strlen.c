#include "string.h"

int my_strlen(char *s)
{
	int length;
	for (length = 0; *(s+length) != '\0'; ++length);
	
	return length;
}