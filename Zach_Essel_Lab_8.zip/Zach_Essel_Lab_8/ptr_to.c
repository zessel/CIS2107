#include "string.h"
#include <stdlib.h>
#include <ctype.h>

/*
returns a pointer to the first occurrence of n in the string h or NULL if it isn't found
*/
char *ptr_to(char *h, char *n)
{
	int location = find(h, n);
	char *return_ptr = NULL;
	
	if (location != -1)
		return_ptr = h+location;
	
	return return_ptr;
}
