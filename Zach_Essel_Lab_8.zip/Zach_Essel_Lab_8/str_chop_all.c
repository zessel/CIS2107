#include "string.h"
#include <stdlib.h>

/*
Returns an array of string consisting of the characters in s split into tokens based on the delimeter c, followed by a NULL pointer.  
For example, if s is "I am ready for a nice vacation" and c is ' ', it returns {"I", "am", "ready", "for", "a", "nice", "vacation", NULL}

The space needed in memory for the string data should be strlen(s) + 1.  The splitter chars all effectively become nulls and you need to
add one additional spot for the final string null. 

User must free resulting array
*/
char **str_chop_all(char *s, char c)
{
	int splitter_count = 0;
	int *index = (int *) malloc (1*sizeof(int));
	char *string_c = &c;
	*(index+splitter_count) = find(s, string_c);
	char *temp_s = s;
	
	while (*(index+splitter_count) != -1)
	{
		temp_s += *(index+splitter_count)+1;
		++splitter_count;
		index = realloc (index, (splitter_count+1) * sizeof(int));
		*(index+splitter_count) = find(temp_s, string_c);
	}
	
	*(index+splitter_count) = my_strlen(temp_s);
	temp_s = s;
	char **return_array = (char **) malloc((splitter_count+1) * sizeof(char *));  //+1 is to account for NULL
	
	for (int i = 0; i < (splitter_count+1); ++i)
	{
		*(return_array+i) = (char *) malloc ((*(index+i)+1) * sizeof(char));
		for (int j = 0; j < *(index+i); ++j)
		{
			*(*(return_array+i)+j) = *(temp_s+j);
		}
		*(*(return_array+i)+*(index+i)) = '\0';
		temp_s += *(index+i)+1;
	}
	
	*(return_array+splitter_count+1) = NULL;

	free(index);
	index = NULL;
	
	return return_array;
}