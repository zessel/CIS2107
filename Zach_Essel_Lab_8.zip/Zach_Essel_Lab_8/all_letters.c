#include "string.h"
#include <ctype.h>

/*
Returns 1 if  all of the  characters  in the string are  either  upper 
-or lower- case  letters of  the  alphabet.  It returns 0 otherwise.
*/
int all_letters(char *s)
{
	int true_false = 1;
	char *temp = s;
	while (*temp != '\0')  //Iterate through string checking for all upper
	{
		if (!isalpha(*temp) && *temp != ' ')
			true_false = 0;
		temp++;
	}
	return true_false;
}
