#include "string.h"

/*
returns 1 if suff 
is a suffix of s ignoring case or 0 otherwise.

*/
int ends_with_ignore_case(char *s, char *suff)
{
	int return_value = 1;

	for (int i = (my_strlen(s)-my_strlen(suff)); i < my_strlen(s); ++i)
	{
		if ((*(s+i) != *(suff+i-my_strlen(suff))) || return_value == 0)
			return_value = 0;
	}
	
	return return_value;
}
