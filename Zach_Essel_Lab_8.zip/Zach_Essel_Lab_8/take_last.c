#include "string.h"

/*
Modifies s so that it consists of only its last n characters.  
If n is ≥ the length of s, the original string is unmodified. 
For example if we call take_last("Brubeck" 5), when the function finishes, the original string becomes "ubeck"

Checks to make sure string it long enough
*/
void take_last(char *s, int n)
{
	if ((n >= 0) && (n <= my_strlen(s)))
	{
		int length = my_strlen(s) - n;
		int i = 0;
		while (*(s+i+length) != '\0')
		{
			*(s+i) = *(s+i+length);
			++i;
		}
	*(s+i) = '\0';
	}
}
