#include "string.h"

/*
removes  whitespace  characters  from  the beginning  of s

This implimentation might be bad for memory.  I've got to read into it.
*/
void rm_left_space(char *s)
{
	int i = 0;
	int j = 0;
	while (*(s+i) == ' ')
		++i;
	while (*(s+j+i) != '\0')
	{
		*(s+j) = *(s+j+i);
		++j;
	}
	*(s+j) = '\0';
}
