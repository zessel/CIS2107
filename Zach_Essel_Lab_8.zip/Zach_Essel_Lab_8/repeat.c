#include "string.h"
#include <stdlib.h>

/*
Returns a new string consisting of the characters in s repeated x times, with the character sep in between. For example,  
if s is the string all right, x is 3, and sep is , the function returns the new string all right,all right,all right. 
If s is NULL, the function returns NULL. It is up to the caller to free any memory allocated by the function.
*/
char *repeat(char *s, int x, char sep)
{
	char *return_string = NULL;
	int length_s = my_strlen(s);
	
	if ((s != NULL) && (x > 0))
	{
		int j;
		return_string = (char*) malloc(((length_s * x)+(x-1)) * sizeof(char));
		for (int i = 0; i < x; ++i)
		{
			for (j = 0; j < length_s; ++j)
			{
				*(return_string+(i*length_s)+j+i) = *(s+j);
			}
			if (i != (x-1))
				*(return_string+(i*length_s)+j+i) = sep;
		}
		*(return_string+(length_s * x)+(x-1)) = '\0';
	}
	
	return return_string;
}
