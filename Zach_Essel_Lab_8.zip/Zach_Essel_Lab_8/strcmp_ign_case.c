#include "string.h"
#include <stdlib.h>
#include <ctype.h>

/*
Compares s1 and s2 ignoring case. Returns a positive number if s1 would appear after s2 
in the dictionary, a negative number if it would appear before s2, or 0 if the two are equal.
*/
int strcmp_ign_case(char *s1, char *s2)
{
	int return_value = 0;
	int i = 0;

	while ((*(s1+i) != '\0') && (*(s2+i) != '\0') && (return_value == 0))
	{
		if (toupper(*(s1+i)) > toupper(*(s2+i)))
			return_value = 1;
		if (toupper(*(s1+i)) < toupper(*(s2+i)))
			return_value = -1;
		++i;
	}
	
	if ((return_value == 0) && ((*(s1+i) != '\0') || (*(s2+i) != '\0')))
	{
		if (my_strlen(s1) < my_strlen(s2))
			return_value = 1;
		if (my_strlen(s1) > my_strlen(s2))
			return_value = -1;
	}
		
	return return_value;
}
