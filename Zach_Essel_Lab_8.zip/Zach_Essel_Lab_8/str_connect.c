#include "string.h"
#include <stdlib.h>

/*
Returns a string consisting of the first n strings in strs with the character c
used as a separator. For example, if strs contains the strings {"Washington", "Adams", "Jefferson"}
and c is '+', the function returns the string "Washington+Adams+Jefferson"

User responsible for freeing returned string memory
*/
char *str_connect(char **strs, int n, char c)
{
	int length_string = n;  
	int return_index = 0;
	int j = 0;
	
	for (int i = 0; i < n; ++i)
	{
		length_string += my_strlen(*(strs+i));
	}
	char *return_string = (char *) malloc(length_string * sizeof(char));

	for (int i = 0; i < n; ++i)
	{
		for (j = 0; *(*(strs+i)+j) != '\0'; ++j)
		{
			*(return_string+j+return_index) = *(*(strs+i)+j);
		}

		if (i != (n-1))
			*(return_string+j+return_index) = c;
		return_index += j+1;
	}

	*(return_string+length_string) = '\0';
	
	return return_string;
}
