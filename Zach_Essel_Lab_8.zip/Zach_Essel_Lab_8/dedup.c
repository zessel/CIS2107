#include "string.h"
#include <stdlib.h>
#include <ctype.h>

/*
returns  a new  string based  on s, but without  any duplicate  characters.  For  example,  if 
s is the string, "There's always money in the banana stand.", the function  returns  the  string 
"Ther's alwymonitbd.". It is up to the caller  to free  the memory  allocated  by the function.

Used 
*/
char *dedup(char *s)
{
	int seen_chars[128] = {0};  // The number of ASCII values
	
	int i = 0;
	int last_copied_i = 0;
	char *temp = NULL;
	temp = (char*) malloc((my_strlen(s)+1) * sizeof(char));
	
	while (*(s+i) != '\0')
	{
		if (seen_chars[*(s+i)] != 1)
		{	
			temp[last_copied_i] = *(s+i);
			++last_copied_i;
		}
//		seen_chars[toupper(*(s+i))] = 1;   These lines count both capital and lowercase as a single character.
//		seen_chars[tolower(*(s+i))] = 1;   Wrote them before I saw the test case and I like them better.
		seen_chars[*(s+i)] =1;
		
		++i;
	}
	char *return_string = NULL;
	return_string = (char*) malloc((last_copied_i+1) * sizeof(char));
	
	for (int k = 0; k < last_copied_i; ++k)
	{
		return_string[k] = temp[k];
	}
	return_string[last_copied_i+1] = '\0';
	free(temp);
	temp = NULL;
	
	return return_string;
}
