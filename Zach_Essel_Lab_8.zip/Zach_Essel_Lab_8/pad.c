#include "string.h"
#include <stdlib.h>

/*
returns a new string consisting of all of the letters of s, but padded with spaces at the end so that the total length 
of the returned string is an even multiple of d. If the length of s is already an even multiple of d, the function 
returns a copy of s. The function returns NULL on failure or if s is NULL. Otherwise, it returns the new string. It is 
up to the caller to free any memory allocated by the function.
*/
char *pad(char *s, int d)
{
	char *return_string = NULL;
	if (s != NULL)
	{
		if (d >= my_strlen(s))
		{
			return_string = (char*) malloc((d+1) * sizeof(char));
		}
		else
		{
			return_string = (char*) malloc(((((int)(my_strlen(s)/d)+1)*d)+1) *sizeof(char));  //not sure if int division is implicit
		}
		int i = 0;
		while (*(s+i) != '\0')
		{
			*(return_string+i) = *(s+i);
			++i;
		}
		while (i < d)
		{
			*(return_string+i) = ' ';
			++i;
		}
		*(return_string+d) = '\0';
	}
	return return_string;
}
