#include "string.h"
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

void main ()
{
	puts("\nall_letters()");
	puts("Input: \"Hello World\"");
	printf("Returns:  %d\n", all_letters("Hello World"));
	puts("Expected: 1\n");
	puts("Input: \"He11o World\"");
	printf("Returns:  %d\n", all_letters("He11o World"));
	puts("Expected: 0\n");
	
	puts("num_in_range()");	
	puts("Input: \"Yellow\" 'f' 'm'");
	printf("Returns:  %d\n", num_in_range("Yellow", 'f', 'm'));
	puts("Expected: 2\n");
	
	puts("diff()");
	puts("Input: \"Book\" \"Back\"");
	printf("Returns:  %d\n", diff("Book", "Back"));
	puts("Expected: 2\n");
	
	char shorten_test[] = "Hello World";
	char shorten_test2[] = "Hello World";
	puts("shorten()");
	puts("Input: \"Hello World\" 5");
	shorten(shorten_test, 5);
	printf("Returns:  %s\n", shorten_test);
	puts("Expected: Hello\n");
	puts("Input: \"Hello World\" 20");
	shorten(shorten_test2, 20);
	printf("Returns:  %s\n", shorten_test2);
	puts("Expected: Hello World\n");
	
	puts("len_diff()");
	puts("Input: \"Philadelphia\" \"Hello\" 5");
	printf("Returns:  %d\n", len_diff("Philadelphia", "Hello"));
	puts("Expected: 7\n");
	
	char left_space_test[] = "  Hello";
	puts("rm_left_space()");
	puts("Input: \"  Hello\"");
	rm_left_space(left_space_test);
	printf("Returns:  \"%s\"\n", left_space_test);
	puts("Expected: \"Hello\"");
	
	char right_space_test[] = "Hello  ";
	puts("\nrm_right_space()");
	puts("Input: \"Hello  \"");
	rm_right_space(right_space_test);
	printf("Returns:  \"%s\"\n", right_space_test);
	puts("Expected: \"Hello\"\n");
		
	char space_test[] = "  Hello  ";
	puts("\nrm_space()");
	puts("Input: \"  Hello  \"");
	rm_space(space_test);
	printf("Returns:  \"%s\"\n", space_test);
	puts("Expected: \"Hello\"\n");
		
	puts("\nfind()");
	puts("Input: \"Hello \" \"l\"");
	printf("Returns:  %d\n", find("Hello ", "l"));
	puts("Expected: 2\n");
	puts("Input: \"Hello \" \"q\"");
	printf("Returns:  %d\n", find("Hello ", "q"));
	puts("Expected: -1\n");
	
	char *driver_ptr = NULL;
	puts("\nptr_to()");
	puts("Input: \"Hello \" \"l\"");
	printf("Returns:  ");
	driver_ptr = ptr_to("Hello ", "l");
	if (driver_ptr != NULL)
		printf("%c\n", *driver_ptr);
	else
		puts("NULL");	
	puts("Expected: l (via pointer)\n");
	puts("\nrm_right_space()");
	puts("Input: \"Hello \" \"q\"");
	printf("Returns:  ");
	driver_ptr = ptr_to("Hello ", "q");
	if (driver_ptr != NULL)
		printf("%c\n", *driver_ptr);
	else
		puts("NULL");
	puts("Expected: NULL\n");
	
	puts("\nis_empty()");
	puts("Input: \"\"");
	printf("Returns:  %d\n", is_empty(""));
	puts("Expected: 1\n");
	puts("Input: \"Hello\"");
	printf("Returns:  %d\n", is_empty("Hello"));
	puts("Expected: 0\n");
	
	char *zip_test = str_zip("Temple", "hello");
	puts("\nstr_zip()");
	puts("Input: \"Temple\" \"hello\"");
	printf("Returns:  %s\n", zip_test);
	puts("Expected: Theemlplloe\n");
	free(zip_test);
	zip_test = NULL;

	char capitalize_test[] = "hello world";
	puts("\ncapitalize()");
	puts("Input: \"hello world\"");
	capitalize(capitalize_test);
	printf("Returns:  %s\n", capitalize_test);
	puts("Expected: Hello World\n");
	
	puts("\nstrcmp_ign_case()");
	puts("Input: \"hello\" \"goodbye\"");
	printf("Returns:  %d\n", strcmp_ign_case("hello", "goodbye"));
	puts("Expected: 1\n");
	puts("Input: \"Hello\" \"hello\"");
	printf("Returns:  %d\n", strcmp_ign_case("Hello", "hello"));
	puts("Expected: 0\n");

	char last_test1[] = "hello";
	char last_test2[] = "hello";
	puts("\ntake_last()");
	puts("Input: \"hello\" 3");
	take_last(last_test1, 3);
	printf("Returns:  %s\n", last_test1);
	puts("Expected: llo\n");
	puts("Input: \"hello\"");
	take_last(last_test2, 6);
	printf("Returns:  %s\n", last_test2);
	puts("Expected: hello\n");

	char *dedup_test = dedup("hello");
	puts("\ndedup()");
	puts("Input: \"hello\"");
	printf("Returns:  %s\n", dedup_test);
	puts("Expected: helo\n");
//	free(dedup_test);    //This line makes str_chop_all crash
	dedup_test = NULL;
	
	char *pad_test1 = pad("hello", 6);
	char *pad_test2 = pad("hello", 5);
	puts("\npad()");
	puts("Input: \"hello\" 6");
	printf("Returns:  \"%s\"\n", pad_test1);
	puts("Expected: \"hello \"\n");
	puts("Input: \"hello\" 5");
	printf("Returns:  \"%s\"\n", pad_test2);
	puts("Expected: \"hello\"\n");
	free(pad_test1);
	pad_test1 = NULL;
	free(pad_test2);
	pad_test2 = NULL;
	
	puts("\nends_with_ignore_case()");
	puts("Input: \"Coding\" \"ing\"");
	printf("Returns:  %d\n", ends_with_ignore_case("Coding", "ing"));
	puts("Expected: 1\n");
	puts("Input: \"Coding\" \"ed\"");
	printf("Returns:  %d\n", ends_with_ignore_case("Coding", "ed"));
	puts("Expected: 0\n");

	char *repeat_test = repeat("hello", 3, '-');
	puts("\nrepeat()");
	puts("Input: \"hello\" 3 '-'");
	printf("Returns:  %s\n", repeat_test);
	puts("Expected: hello-hello-hello\n");
	free(repeat_test);
	repeat_test = NULL;
	
	char *replace_test = replace("Steph is the X", "X", "best");
	puts("\nreplace()");
	puts("Input: \"Steph is the X\" \"X\" \"best\"");
	printf("Returns:  %s\n", replace_test);
	puts("Expected: Steph is the best\n");
	free(replace_test);
	replace_test = NULL;

	char *connect_test[] = {"Hello", "world", "Hello", "world"};
	puts("\nstr_connect()");
	puts("Input: {\"Hello\" \"world\" \"Hello\" \"world\"} 4 '-'");
	printf("Returns:  %s\n", str_connect(connect_test, 4, '-'));
	puts("Expected: Hello-world-Hello-world\n");
	
	char *empties_test[] = {"Hello", "World", "", "", "Steph", NULL};
	int y = 0;
	puts("\nrm_empties()");
	puts("Input: {\"Hello\" \"World\" \"\" \"\" \"Steph\" NULL}");
	printf("%s","Returns:  ");
	rm_empties(empties_test);
	while (*(empties_test+y) != NULL)
	{
		printf("%s ", *(empties_test+y));
		++y;
	}
	puts("");
	puts("Expected: Hello World Steph\n");
	
	char **chop_all_test = str_chop_all("Hello/world/hello/world", '/');
	puts("\nstr_chop_all()");
	puts("Input: \"Hello/world/hello/world\" '/'");
	printf("Returns:  ");
	int z = 0;
	while (*(chop_all_test+z) != NULL)
	{
		printf("%s ", *(chop_all_test+z));
		++z;
	}
	chop_all_test = NULL;
	puts("");
	puts("Expected: Hello world hello world\n");

}