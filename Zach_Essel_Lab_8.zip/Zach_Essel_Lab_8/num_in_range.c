#include "string.h"

/*
returns  the number  of  characters c in s1 such that b<=c<=t
checks that there is a range between b and t before any execution
*/
int num_in_range(char *s1, char b, char t)
{
	int count = 0;
	char *temp = s1;
	if (b <= t)
		while (*temp != '\0')
		{
			if (*temp >= b && *temp <= t)
				count++;
			temp++;
		}
	return count;
}
