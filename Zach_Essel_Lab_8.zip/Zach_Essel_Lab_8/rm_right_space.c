#include "string.h"

/*
removes  whitespace  characters  from  the end  of s
*/
void rm_right_space(char *s)
{
	int length = my_strlen(s);
	int whitecount = 0;
	while (*(s+(length-1)) == ' ')
		length--;
	shorten(s, length);
}
