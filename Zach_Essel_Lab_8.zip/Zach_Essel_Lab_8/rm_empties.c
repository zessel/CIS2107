#include "string.h"
#include <stdlib.h>

/*
words is an array of string terminated with a NULL pointer. The function removes any empty strings 
(i.e. strings of  length 0) from  the  array.

I have an i-- in the for loop which is probably a terrible practice but it was a one line fix that made sense
to me so I just kept it.
Running time could also be improved by doing array_size-- along with i-- but I'll save that for another time.
*/
void rm_empties(char **words)
{
	int array_size = 0;
	while (*(words+array_size) != NULL)
	{
		++array_size;
	}
	for (int i = 0; i < array_size; ++i)
	{
		if ((*(words+i) != NULL) && (my_strlen(*(words+i)) == 0))
		{
			int j = i;
			while (*(words+j) != NULL)
			{
				if (*(words+j) != NULL){
				*(words+j) = *(words+j+1);}
				++j;
			}
			i--;
		}
	}
}
