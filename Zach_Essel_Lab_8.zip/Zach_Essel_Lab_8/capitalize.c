#include "string.h"
#include <stdlib.h>
#include <ctype.h>

/*
Changes s so that the first letter of  every  word  is in  upper  case and  each  additional  letter is in lower  case.
*/
void capitalize(char *s)
{
	int i = 0;
	
	while (*(s+i) != '\0')
	{
		if (i == 0)  			// not on one line so that the else catches all non i.  Should move outside loop for less comparisons
		{
			if (isalpha(*s))  
			{
				*(s+i) = toupper(*(s)); // value to change upper and lower
			}
		}
		else if (((*(s+i-1) == ' ')) && (isalpha(*(s+i))) && (islower(*(s+i))))
			*(s+i) = toupper(*(s+i));
		else if ((isalpha(*(s+i-1))) && (isalpha(*(s+i))))
			*(s+i) = tolower(*(s+i));
		++i;
	}
}
