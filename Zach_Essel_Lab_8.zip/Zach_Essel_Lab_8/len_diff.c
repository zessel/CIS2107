#include "string.h"

/*
Returns  the  length  of s1 - the  length  of s2
*/
int len_diff(char *s1, char *s2)
{
	return my_strlen(s1) - my_strlen(s2);
}
