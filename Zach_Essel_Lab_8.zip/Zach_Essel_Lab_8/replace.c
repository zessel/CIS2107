#include "string.h"
#include <stdlib.h>

/*
Returns a copy of the string s, but with each instance of pat replaced with rep, note that len(pat)
can be less than, greater than, or equal to len(rep). The function allocates memory for the resulting string, and it is up to 
the caller to free it. For example, if we call replace("NBA X", "X", "rocks"), what is returned is the new 
string NBA rocks (but remember, pat could be longer than an individual character and could occur multiple times).

First we copy s to a new string on heap to return no matter what.  Could do a NULL check but I haven't.
Then check if there is even a string match to replace (find)
If there is, because the all of s already exists on return_string take another pointer to s and update it
	so that it starts after the end of the found pat
Add the rep to return_string
Add the rest of s (including potential future pats) to return string
Update the index int of return_string to account for rep's length
Search again 
*/
char *replace(char *s, char *pat, char *rep)
{
	int length_pat = my_strlen(pat);
	int length_rep = my_strlen(rep);
	int replace_index = 0;
	int return_index = 0;
	int i = 0;
	int j = 0;
	char *return_string = NULL; 
	
	char *temp_s = s;
	
	return_string = (char *) malloc((my_strlen(s) + 1) * sizeof(char));
	while (*(s+i) != '\0')
	{
		*(return_string+i) = *(s+i);
		++i;
	}
	*(return_string+i) = '\0';
	
	replace_index = find(temp_s, pat);
	while (replace_index != -1)
	{
		return_index += replace_index;
		temp_s += replace_index + length_pat;
		
		return_string = (char *) realloc(return_string,((my_strlen(return_string)-length_pat+length_rep+1)* sizeof(char)));

		for (i = 0; i < length_rep; ++i)
			*(return_string+return_index+i) = *(rep+i);
		for (j = 0; *(temp_s+j) != '\0'; ++j)
			*(return_string+return_index+i+j) = *(temp_s+j);

		*(return_string+return_index+i+j) = '\0';
		return_index += length_rep;
		replace_index = find(temp_s, pat);
	}		
	return return_string;		
}
