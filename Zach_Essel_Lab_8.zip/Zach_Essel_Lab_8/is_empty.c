#include "string.h"
#include <stdlib.h>
#include <ctype.h>

/*
returns 1 if s is NULL, consists of only the null character ('') or only whitespace. Returns 0 otherwise.
*/
int is_empty(char *s)
{
	int return_value = 1;
	int i = 0;
	
	if (s != NULL)
	{
		while (*(s+i) != '\0')
		{
			if (*(s+i) != ' ')
				return_value = 0;
			++i;
		}
	}
	return return_value;
}
