#include "string.h"

/*
returns the number of positions in which s1 and s2 differ, i.e., it returns 
the number of changes that would need to be made in order to transform 
s1 into s2, where  a change  could  be  a character  substitution, an insertion,  or  a deletion.

3 cases possible: s1 is larger, s1 and s2 are even in length, s1 is smaller.  
Function calculates the length difference first before making a char by char comparison
*/
int diff(char *s1, char *s2)
{
	int differences = len_diff(s1, s2);
	
	if (differences < 0)
		differences *= -1;
	char *temp1 = s1;
	char *temp2 = s2;
	
	while (*temp1 != '\0' && *temp2 != '\0')
	{
		if (*temp1 != *temp2)
			differences++;
		temp1++;
		temp2++;
	}
	return differences;
}
